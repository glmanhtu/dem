#include "meshing.h"

Meshing::Meshing(GDALDataset *pData)
{
    this->pData = pData;
}

vector<float*> Meshing::createVertexArray()
{
    vector<float*> vertices;
    float fMyArray[ ] = { 1.0f, 1.5f, 2.0f };
    vertices.push_back(fMyArray);
    return vertices;
}

Meshing::~Meshing()
{

}
