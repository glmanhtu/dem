#ifndef DEMINTERFACE_H
#define DEMINTERFACE_H

class DemInterface
{
public:
    DemInterface();
};

#endif // DEMINTERFACE_H
