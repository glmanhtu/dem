#include "filecontroller.h"
#include <QDebug>
#include <QFileDialog>
#include "demobject.h"
#include "gdal.h"
#include "gdal_priv.h"
#include "View/graphics.h"

FileController::FileController(QObject *parent): QObject(parent)
{
    demObject = NULL;

}

void FileController::setGraphics(GraphicsComposite *graphics)
{
    this->graphics = graphics;
}

void FileController::openFile()
{
    QString fileName = QFileDialog::getOpenFileName((Graphics*)graphics->getMainGraphics(),
        QString("Open Dem file"), "/home", QString("Image Files (*.dt0 *.dt1 *.dt2 *.tif)"));
    GDALAllRegister();
    QByteArray ba = fileName.toLatin1();
    const char *c_fileName = ba.data();
    GDALDataset* pDataset = (GDALDataset*) GDALOpen(c_fileName, GA_ReadOnly);
    int rows, cols;
    cols = pDataset->GetRasterXSize();
    rows = pDataset->GetRasterYSize();
    demObject->setSize(rows*cols*4*18);

    GDALRasterBand* band = pDataset->GetRasterBand(1);
    std::vector<float> band_data(cols*rows);

    // Read the data
    band->RasterIO( GF_Read, 0, 0,
                    cols, rows,
                    band_data.data(),
                    cols, rows,
                    GDT_Float32,
                    0, 0);

    int centerX = cols/2;
    float posX, posY, posZ = 0;
    int centerY = rows/2;
    float maxZ = *std::max_element(band_data.begin(), band_data.end());

    for (int k = 0; k < rows; k++) {
        posY = (float)(centerY - k)/centerY;
        for (int j =0; j < cols; j++) {

            posX = (float)(j - centerX)/centerX;
            posZ = (float)band_data[k*rows + j] / maxZ;
            if (k > 0 && j > 0 && k < rows && j < cols) {



                float nposY = (float)(centerY - (k -1))/centerY;
                float nposZ = (float)band_data[(k-1)*rows + j] / maxZ;



                float nposX = (float)(j -1 - centerX)/centerX;
                nposZ = (float)band_data[k*rows + j -1] / maxZ;


                demObject->tri(
                            QVector3D(posX, posY, posZ),
                            QVector3D(posX, nposY, nposZ),
                            QVector3D(nposX, posY, nposZ));
            }


        }
    }

    graphics->getMainGraphics()->initializeGL();
}

void FileController::initAction()
{

}
void FileController::terminalAction()
{

}
QString FileController::getActionName()
{
    return "File.FileController";
}
bool FileController::loadOnBoot()
{
    return false;
}
bool FileController::requireDemObject()
{
    return true;
}
void FileController::setDemObject(DemInterface *dem)
{
    demObject = dem;
}

DemInterface* FileController::getDemObject()
{
    return demObject;
}

