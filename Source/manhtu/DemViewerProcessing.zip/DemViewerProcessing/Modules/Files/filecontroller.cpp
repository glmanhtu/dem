#include "filecontroller.h"
#include <QDebug>
#include <QFileDialog>
#include "gdal.h"
#include "gdal_priv.h"
#include "View/graphics.h"

FileController::FileController(QObject *parent): QObject(parent)
{
    demObject = NULL;

}

void FileController::setGraphics(GraphicsComposite *graphics)
{
    this->graphics = graphics;
}

void FileController::openFile()
{
    QString fileName = QFileDialog::getOpenFileName((Graphics*)graphics->getMainGraphics(),
        QString("Open Dem file"), "/home", QString("Image Files (*.dt0 *.dt1 *.dt2 *.tif)"));
    GDALAllRegister();
    QByteArray ba = fileName.toLatin1();
    const char *c_fileName = ba.data();
    GDALDataset* pDataset = (GDALDataset*) GDALOpen(c_fileName, GA_ReadOnly);
    demObject->setGDALDataSet(pDataset);

    int rows, cols;
    cols = pDataset->GetRasterXSize();
    rows = pDataset->GetRasterYSize();

    demObject->clean();
    demObject->setSize(40*6);
    const GLfloat x1 = +0.06f;
    const GLfloat y1 = -0.14f;
    const GLfloat x2 = +0.14f;
    const GLfloat y2 = -0.06f;
    const GLfloat x3 = +0.08f;
    const GLfloat y3 = +0.00f;

    demObject->tri(QVector3D(x1, y1, 0), QVector3D(x2, y2,0), QVector3D(x3, y3,0));
    graphics->updateGraphics();
}

void FileController::initAction()
{

}
void FileController::terminalAction()
{

}
QString FileController::getActionName()
{
    return "File.FileController";
}
bool FileController::loadOnBoot()
{
    return false;
}
bool FileController::requireDemObject()
{
    return true;
}
void FileController::setDemObject(DemInterface *dem)
{
    demObject = dem;
}

DemInterface* FileController::getDemObject()
{
    return demObject;
}

